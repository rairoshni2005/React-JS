import './App.css'
import ProductList from './component/ProductList'



function App() {
  return (
    <>
        <ProductList></ProductList>
    </>
  )
}

export default App
