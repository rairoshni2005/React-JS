import { useEffect, useState } from 'react';
import Product from './Product.jsx';
import './ProductList.css'
function ProductList() {



    let [products, setProducts] = useState([]);

    useEffect(() => {
    fetch("https://fakestoreapi.com/products", {
      method: "GET"
    })
    .then((response) => response.json())
    .then((data) => {
      setProducts(data);
      console.log(data);
    })
    .catch((err) => {
      console.log(err);
    });
    }, []);

    // let products = [
    //     {
    //         id:1,
    //         name:"Nike Blazer Mid Vintage Sneakers",
    //         price:"2,600",
    //         imageUrl:"https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQToSeVA67-H5DV28dcqPqM-Qbr5C8pY8gD1mdVEzKbdeB9VXFhAXRtyUGsc_OUWFGdCSbUjRPeouPfQ4UIy0okcJZMaQsUw3CO4yWV3vMA&usqp=CAE"
    //     },
    //     {
    //         id:2,
    //         name:"Nike Air Force 1 x Gradient UK 6",
    //         price:"12,800",
    //         imageUrl:"https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcQwWvU9ouo_PHfjZtxBNfjdFJ85Laah6W3zluZwLZr1UH_qWd1nLYW6lTw8-EsTYeIe5Er6L4hNTtad_vAqf-mPiUdCdrtb4jKrJfRNm6pd&usqp=CAE"
    //     },
    //     {
    //         id:3,
    //         name:"Nike Blazer Mid Vintage Sneakers",
    //         price:"20,847",
    //         imageUrl:"https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTYgkLgvDvSHgrMAySSWs0boF84LrMoTi7A7Xw-y1sJfAQ4jHMR0faQicmyGpzUtYSIwnW8HvPkxIVj2CXxRhkmQ0nf4KOc1Qw99BMWv-gQ&usqp=CAEE"
    //     },
    //     {
    //         id:4,
    //         name:"Nike White & Beige Waffle Nav Sneakers",
    //         price:"7,095",
    //         imageUrl:"https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcR-Oz1GrGoKEYyyJOlHFansyP0Hr_L2CPKkW6GuKib2GmaGo1dkYrJdcnJY1rD6olDj5a2FgX20uSiuDVW7sRBLwwmyVBh3o6kQAvndX8rkzcs_oEk44_rMr0Y&usqp=CAE"
    //     },
    //     {
    //         id:5,
    //         name:"Off - AF1 : Earth",
    //         price:"19,990",
    //         imageUrl:"https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQ7ESfJ_TzUtBS7I8CRiVPy23e5DG7bqc7dFan6PgWKz2xEjYIdX6ss4tkxJsdNKbe55XP7aWIMFF8evCY8abKCwfv-sewqxnG-TexfIsTMlLzUCi0U5DUIEQ&usqp=CAE"
    //     },

    // ]






  return (
    <section className='Product_list'>
        {/* <Product 
        name={products[0].name}
        imageUrl={products[0].imageUrl}
        price={products[0].price}/>


        <Product 
        name={products[1].name}
        imageUrl={products[1].imageUrl}
        price={products[1].price}/>

        <Product 
        name={products[2].name}
        imageUrl={products[2].imageUrl}
        price={products[2].price}/>

        <Product 
        name={products[3].name}
        imageUrl={products[3].imageUrl}
        price={products[3].price}/>

        <Product 
        name={products[4].name}
        imageUrl={products[4].imageUrl}
        price={products[4].price}/> */
        
        products.map((prod)=>{
            return(<Product
            name={prod.title}
            price={prod.price}
            imageUrl={prod.image}
            
            
            
            />)
        })
        
        }


    </section>
  )
}

export default ProductList;