import React, { useEffect } from 'react';
import { useState } from 'react';
import './App.css';

function App() {

    let [users,setUsers] = useState([])




  //api calling
  useEffect(()=>{

    fetch("https://jsonplaceholder.typicode.com/users",{
      method:"GET"
    })
    .then((response)=>{
      return response.json()
    })
    .then((data)=>{
      setUsers(data)
      console.log(data)
    })
    .then((err)=>{
      console.log(err)
    })


  },[])
  let [name, setName] = useState("Roshni");
  let [age, setAge] = useState(18);
  let [items, setItems] = useState([]);

  useEffect(() => {
    console.log("First UseEffect");
  }, []);

  useEffect(() => {
    console.log("Second UseEffect");
  }, [age]);

  const addItem = () => {
    setItems(items => [...items, 'item' + (items.length + 1)]);
  };

  //name & age changing & add  itmes on click
  return (
    <>
      <h1>Welcome {name} {age}</h1>
      <button onClick={() => {
        setName("Hanshika");
      }}>Change Name</button>

      <button onClick={() => {
        setAge(20);
      }}>Change Age</button>


      <button onClick={addItem}>Add Item</button>        

      <ol>
        {items.map((item, index) => (
          <li key={item + index}>{item}</li>
        ))}
      </ol>


          {

            users.map((user)=>{
              return(
                <h1>{user.name}</h1>
              )
            })


          }


    </>
  );
}

export default App;
