// userSlice.js

import { createSlice } from '@reduxjs/toolkit';

export const userSlice = createSlice({
  name: 'user',
  initialState: {
    value: 'Roshni', // Initial state is 'Roshni'
  },
  reducers: {
    changeName: (state, action) => {
      state.value = action.payload; // Update user value with the payload
    },
  },
});

export const { changeName } = userSlice.actions;

export default userSlice.reducer;
