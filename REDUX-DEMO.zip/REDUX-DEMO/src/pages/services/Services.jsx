import React from "react";
import styles from "./Services.module.css";
import Navigation from "../../components/navigation/Navigation";

function Services() {
  
  return (
  <>
  <Navigation/><div className={styles.container}>Services</div>
  </>
  );
}

export default Services;
