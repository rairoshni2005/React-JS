import React from 'react';
import styles from './Home.module.css';
import Navigation from '../../components/navigation/Navigation';
import { useSelector, useDispatch } from 'react-redux';
import { changeName } from '../../slices/userSlice';
import { addProduct } from '../../slices/productSlice';

function Home() {
  const username = useSelector(state => state.user.value);
  const products = useSelector(state => state.product.value);
  const dispatch = useDispatch();

  return (
    <>
      <Navigation />
      <div className={styles.container}>
        <h1>Home {username}</h1>
        <div className={styles.buttons}>
          <button onClick={() => dispatch(changeName("Simi"))}>Change Redux Name</button>
          <button onClick={() => dispatch(addProduct({ name: "Sketches", price: 2999 }))}>Add Element</button>
        </div>
        <div className={styles.products}>
          {products.map((prod, index) => (
            <div key={index} className={styles.product}>
              <h2>{prod.name}</h2>
              <p>Price: ${prod.price}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Home;
