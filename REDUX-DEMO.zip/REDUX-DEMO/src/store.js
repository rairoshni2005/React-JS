import { configureStore } from "@reduxjs/toolkit";
// import userSlice from "./slices/userSlice";
import userReducer from './slices/userSlice'
import productReducer from './slices/productSlice'
export const store = configureStore({               //store object
    reducer:{
        user: userReducer,
        product:productReducer
    },
});



