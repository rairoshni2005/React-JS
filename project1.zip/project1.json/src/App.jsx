import './App.css'
import {useState} from 'react'
import ProductList from './components/ProductList'

function App() {

  let [name,setName] = useState("Travellers !!!")
  function doSomething()
  {
    setName("Buddiess")
  }
  function printName(name)
  {
    console.log(name)
  }
  return (
    <>
      <div className="header">
            <h1>Welcome {name} </h1>
            <button className ='btn'onClick={doSomething} > Login In </button>
            <button className ='btn'onClick={()=>{printName("Roshni")}} > Know More </button>
      </div>

      <ProductList />
    </>
  )
}
export default App