import Product from './Product'
import './ProductList.css'
function ProductList() {
  return (
    <section className='Product-List'>
      <div className="container">
            <Product name = "Maldvies"
            imageUrl = "https://so-hotels.com/wp-content/uploads/sites/19/2023/06/Aerial-3_SOMaldivesjpg-1200x1400-1.jpg"
            Price = "2,00,000"/> 

            <Product name = "Bali"
            imageUrl = "https://media.cntraveler.com/photos/5c263e13a6a145617b7c77ba/master/pass/Karma-Beach-Club_Karma-Beach-Bali-.jpg"
            Price = "1,00,000"/> 
      </div>
    </section>
  )
}

export default ProductList