import './App.css'
import CreateProduct from './pages/CreateProduct'

function App() {

  return (
    <>
      <CreateProduct></CreateProduct>
    </>
  )
}

export default App
