import React, { useState } from 'react'
import './CreateProduct.css'

function CreateProduct() {
    const [product, setProduct] = useState({})

    function handleInput(event) {
        const { name, value } = event.target
        setProduct(prevProduct => ({
            ...prevProduct,
            [name]: value
        }))
    }

    function handleSubmit(event) {
        event.preventDefault()
        console.log(product)

        fetch("url", {
            method: "POST",
            body: JSON.stringify(product),
            headers:{
              "Content-Type": "application/json"
            }
        })
        .then((response) => {})
        .catch((error) => {})
    }

    return (
        <section className="form-parent">
            <form className='form' onSubmit={handleSubmit}>
                <h1>Add Product</h1>
                <input className='inp' required name='name' type="text" placeholder='Enter Name' onChange={handleInput} />
                <input className='inp' name='price' type="number" placeholder='Enter Price' onChange={handleInput} />
                <input className='inp' name='category' type="text" placeholder='Enter Category' onChange={handleInput} />
                <input className='inp' name='quantity' type="number" placeholder='Enter Quantity' onChange={handleInput} />
                <input className='inp' name='description' type="text" placeholder='Enter Description' onChange={handleInput} />
                <button type='submit' className='btn'>Add</button>
            </form>
        </section>
    )
}

export default CreateProduct
